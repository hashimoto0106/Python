# -*- coding: utf-8 -*-
"""
Created on Wed Sep 12 22:25:05 2018

@author: hashimoto
"""

import numpy as np


def main():
    # データ
    data = np.array([31, 30, 27, 25, 29, 34, 32, 31, 30, 29])

    # CSVファイル読み込み
    data = np.loadtxt("wireshark_capture_log.csv", delimiter=",", skiprows=1)
    print(data)

    # 合計
    sum = np.sum(data)
    print(u"合計"+str(sum))

    # 平均
    mean = np.mean(data)
    print(u"平均"+str(mean))

    # 最小
    min = np.min(data)
    print(u"最小"+str(min))

    # 最大
    max = np.max(data)
    print(u"最大"+str(max))

    # 標準偏差
    std = np.std(data)
    print(u"標準偏差："+str(std))

    # 分散
    var = np.var(data)
    print(u"分散："+str(var))


if __name__ == '__main__':
    main()
